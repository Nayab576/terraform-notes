
#OnlineReservationSystem
<br>
<img src="https://dev.azure.com/vishal191942/OnlineReservationSystem/_apis/build/status/OnlineReservationSystem-ASP.NET-CI?branchName=master">
<br>
<br>

Azure Boards [ Online Reservation System Team ]
<br>
[![Board Status](https://dev.azure.com/vishal191942/2f5bcb31-5dc0-4452-9f2c-1393571e178c/c120e76e-f7be-4ca7-864e-820643bef035/_apis/work/boardbadge/e5691957-4f49-4b2a-b29a-d7beb9f467d2?columnOptions=1)](https://dev.azure.com/vishal191942/2f5bcb31-5dc0-4452-9f2c-1393571e178c/_boards/board/t/c120e76e-f7be-4ca7-864e-820643bef035/Microsoft.RequirementCategory/)
<br>
<br>
[![Quality gate](http://newvmdocker1.eastus.cloudapp.azure.com:9000/api/project_badges/quality_gate?project=OnlineReservationSystem_OnlineReservationSys_AYC8UPw67DixGpK4i04V&token=1fcd535f7341ff61ea388cb0698ab6a4afff3297)](http://newvmdocker1.eastus.cloudapp.azure.com:9000/dashboard?id=OnlineReservationSystem_OnlineReservationSys_AYC8UPw67DixGpK4i04V)<br>
This project is the trial for getting the insights of Azure DevOps services and its functioning in the process of Managing the Project codes and pipelines.